# IDT_TFTD_StormingTheAbyss + Vanilla Plus by Daev
 Small patch to get StA and V+ to work together. To be able to enable and make them work, the loading order must be:

 * Vanilla Plus
 * Storming the Abyss
 * Storming the Abyss + V Plus patch

Otherwise, you can copy and paste this in your options file:

  - active: true
    id: VPLUS
  - active: true
    id: IDT_STA
  - active: true
    id: IDT_STA_VPlus